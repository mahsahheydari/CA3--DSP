[s,Fs] = audioread('sonata.mp3');
tt= (0: length(s)-1)/Fs;
s1 =s(:,1);
s2 = s(:,2);
h= length(s)
ss = fftshift(fft(s2))
ff = (-h/2: h/2-1)*Fs/h;
power = abs(ss).^2/h;
figure(23)
plot(ff,power)
title("power")
figure(12)
plot(tt,s1)
hold on
plot(tt,s2)
title("time domain")
xlabel("t sec")
figure(13)
f= -length(abs(fftshift(fft(s1))))/2:length(abs(fftshift(fft(s1))))/2-1;

plot(f,abs(fftshift(fft(s1))));
hold on
plot(f,abs(fftshift(fft(s2))));
title("fft")

