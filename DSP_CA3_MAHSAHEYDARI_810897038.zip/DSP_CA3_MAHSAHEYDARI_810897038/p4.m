[arnold,Fs] = audioread('Arnold.wav'); 
 california = audioread('California.wav');  
corr = normalize(xcorr(arnold,california)); 
Y= corr(length(corr)/2:length(corr),:);
 [~,idx] = max(Y);  
t = (0:length(arnold)-1)/Fs;
 T = (0: length(california)-1)/Fs  ;       
 w = 2*pi*1000;   
  s = sin(w*T); 
  arnold=arnold.';
 arnold(idx+1:idx+length(s))= s;
 sound(arnold, Fs)  
 audiowrite('censored.wav',arnold,Fs);    
 plot(corr/max(Y))
 title("correlation arnold and california")