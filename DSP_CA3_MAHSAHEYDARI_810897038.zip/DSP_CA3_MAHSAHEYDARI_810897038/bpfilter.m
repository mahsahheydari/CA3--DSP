function filter_output = bpfilter(x,f,f_low,f_high)
filter_output = zeros(length(x));
pos_low = find(f==f_low);pos_high = find(f==f_high)
neg_low = find(f==-f_low);neg_high = find(f == -f_high)
for i=1:length(x)
    if((i<=pos_high & i>=pos_low) | (i>=neg_high & i<=neg_low))
        filter_output(i,1) = x(i);
    else
        filter_output(i,1) = 0;
    end
end
end

     