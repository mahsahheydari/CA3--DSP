v1c = cepstrum (example_v1);
v2c = cepstrum (example_v2);
v3c = cepstrum (example_v3);

figure(22)
subplot(1,2,1)
plot(abs(v1c))
ylim([0 0.4])
title("v1 cepstrum")
subplot(1,2,2)
plot(abs(fftshift(fft(example_v1))))

figure(1)
subplot(3,1,1)
plot(abs(v1c))
ylim([0 0.4])
title("v1 cepstrum")
subplot(3,1,2)
plot(abs(v2c))
ylim([0 0.4])
title("v2 cepstrum")
subplot(3,1,3)
plot(abs(v3c))
ylim([0 0.4])
title("v3 cepstrum")
xlabel("samples")

