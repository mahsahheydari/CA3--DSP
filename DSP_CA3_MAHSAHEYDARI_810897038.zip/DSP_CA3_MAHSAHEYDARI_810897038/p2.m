load('v1.mat', 'val')
example_v1= val(5,:)
load('v2.mat', 'val')
example_v2= val(10,:)
load('v3.mat', 'val')
example_v3= val(15,:)
fs= 160
L= length(example_v1)
t= (0:L-1)/fs;
f = (-L/2:L/2-1)*(fs/L)


%decomposition alfa delta gamma beta teta

delta = bpfilter(fftshift(fft(example_v2)),f, 0.5, 4);
theta = bpfilter(fftshift(fft(example_v2)),f, 4, 8);
alpha = bpfilter(fftshift(fft(example_v2)),f, 8, 12);
beta = bpfilter(fftshift(fft(example_v2)),f, 12, 35);
gamma = bpfilter(fftshift(fft(example_v2)),f, 35,f(length(f)));



idelta = ifft(delta);
itheta = ifft(theta);
ialpha = ifft(alpha);
ibeta = ifft(beta);
igama = ifft(ifftshift(gamma));


figure(1)
subplot(3,1,1)

plot(t,example_v1)
title("v1")
subplot(3,1,2)
plot(t,example_v2)
title("v2")
subplot(3,1,3)
plot(t,example_v3)
title("v3")
xlabel("time(s)")

figure(2)
subplot(3,1,1)
plot(f,abs(fftshift(fft(example_v1))))

title(" fft v1")
subplot(3,1,2)
plot(f,abs(fftshift(fft(example_v2))))
title(" fft v2")
subplot(3,1,3)
plot(f,abs(fftshift(fft(example_v3))))
title("fft v3")
xlabel("Freq(Hz)")

figure(3)
subplot(5,1,1)
plot(t,idelta,'b')
title("DELTA")
subplot(5,1,2)
plot(t,itheta,'b')
title("THETA")
subplot(5,1,3)
plot(t,ialpha,'b')
title("ALPHA")
subplot(5,1,4)
plot(t,ibeta,'b')
title("BETA")
subplot(5,1,5)
plot(t,igama,'b')
title("GAMMA")
