function yc =cepstrum(x)
xfft = fft(x);
x_log= log(xfft);
yc= ifft(x_log)
end