figure(1)
spectrogram(s2,160,10,128,Fs,'yaxis')